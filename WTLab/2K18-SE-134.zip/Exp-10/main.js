const popup = document.getElementById('popup');

window.onload = () => {
    setTimeout(() => {
        popup.style.display = 'flex';
    }, 1000);
}