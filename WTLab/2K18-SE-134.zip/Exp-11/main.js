window.onload = () => {
    setTimeout(() => {
        console.log('Changing background color');
        document.body.style.backgroundColor = '#2c2c2c'
    }, 5000);
}